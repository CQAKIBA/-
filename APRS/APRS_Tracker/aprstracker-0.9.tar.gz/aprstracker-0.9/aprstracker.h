/*
 *	aprstracker.h
 *
 *	Copyright Jeroen Vreeken (pe1rxq@amsat.org), 2003, 2004, 2005
 *
 *	Published under the terms of the GNU General Public License
 *	version 2. Read the file COPYING for more details.
 */

#ifndef _INCLUDE_APRSTRACKER_H_
#define _INCLUDE_APRSTRACKER_H_


#if defined(_16F627) || defined(_16F628)
	__CONFIG(HS & WDTEN & PWRTEN & BOREN & LVPDIS & DATUNPROT & UNPROTECT);
#endif
#if defined(_16F84)
	__CONFIG(HS & WDTEN & PWRTEN & UNPROTECT);
#endif


#define APRSTRACKER_VERSION	0x09

/*
 *	EEPROM defaults
 */

/* memmory layout version */
#define APRSTRACKER_EEVERSION	0x02

#asm
	psect	eeprom_data,class=EEDATA,delta=2

	/* position 0x00-0x06 destination address APERXQ-0 */
	db	'A'<<1, 'P'<<1, 'E'<<1, 'R'<<1, 'X'<<1, 'Q'<<1, '0'<<1
	/* position 0x07-0x0d source address NOCALL-0 */
	db	'N'<<1, 'O'<<1, 'C'<<1, 'A'<<1, 'L'<<1, 'L'<<1, '0'<<1
	/* position 0x0e-0x14 first digipeater RELAY-0 */
	db	'R'<<1, 'E'<<1, 'L'<<1, 'A'<<1, 'Y'<<1, ' '<<1, '0'<<1
	/* position 0x15-0x1b second digipeater WIDE2-2 */
	db	'W'<<1, 'I'<<1, 'D'<<1, 'E'<<1, '2'<<1, ' '<<1, ('2'<<1) + 1
	/* position 0x1c beaconinterval (minutes)
	 * when set to 0 then smartbeaconting(tm) is enabled
	 * any other value sets fixed beacon interval */
	#define EE_BEACONTIME	0x1c
	db	0
	/* position 0x1d txdelay (flags) */
	#define EE_TXDELAY	0x1d
	db	50
	/* position 0x1e symbol table */
	#define EE_SYMBOLTABLE	0x1e
	db	'/'
	/* position 0x1f symbol id */
	#define EE_SYMBOLID	0x1f
	db	'>'
	/* position 0x20 and up beacontext (null terminated) */
	#define EE_BEACONTEXT	0x20
	db	0, 0, 0, 0, 0, 0, 0, 0
	db	0, 0, 0, 0, 0, 0, 0, 0
	db	0, 0, 0, 0, 0, 0, 0, 0
	db	0, 0, 0, 0, 0, 0, 0, 0
	db	0, 0, 0, 0, 0, 0, 0, 0
	/*
	 * SmartBeaconing(tm) variables. 
	 * Change these to tweak SmartBeaconing(tm) behaviour.
	 * But be carefull because small changes could easily lead to
	 * flooding the network!
	 */
	// Min threshold for corner pegging (degrees)
	#define SB_TURN_MIN	0x48
	db	20
	// Threshold slope for corner pegging (degrees/knot)
	#define SB_TURN_SLOPE	0x49
	db	25
	 // Time between other beacon & turn beacon (secs)
	#define SB_TURN_TIME	0x4a
	db	5
	// Fast beacon rate (secs)
	#define SB_POSIT_FAST	0x4b
	db	90
	// Slow beacon rate (mins)
	#define SB_POSIT_SLOW	0x4c
	db	20
	// Speed below which SmartBeaconing(tm) is disabled we'll beacon at
	// the POSIT_slow rate (knots)
	#define SB_LOW_SPEED_LIMIT	0x4d
	db	3
	// Speed above which we'll beacon at the POSIT_fast rate (knots)
	#define SB_HIGH_SPEED_LIMIT	0x4e
	db	50
#endasm

/*
 *	IO ports
 */

static bit LSTAT	@(unsigned)&PORTA*8+0;
static bit LGPS 	@(unsigned)&PORTA*8+1;
static bit PTT 		@(unsigned)&PORTA*8+2;
static bit TXD		@(unsigned)&PORTA*8+3;
static bit RXD		@(unsigned)&PORTA*8+4;

static bit R8K2		@(unsigned)&PORTB*8+0;
static bit R3K9		@(unsigned)&PORTB*8+1;
static bit R2K0		@(unsigned)&PORTB*8+2;
static bit R1K0		@(unsigned)&PORTB*8+3;

// keep in mind that RXDET is TRUE if channel is free
static bit RXDET	@(unsigned)&PORTB*8+4;
static bit SEND		@(unsigned)&PORTB*8+5;
static bit SW1		@(unsigned)&PORTB*8+6;
static bit SW2		@(unsigned)&PORTB*8+7;

/* Only the receiving pins */
/* A4 = 16 */
#define INIT_PORTA	TRISA = 16
/* B4 = 16, B5 = 32, B6 = 64, B7 = 128 */
#define INIT_PORTB	TRISB = 16 + 32 + 64 + 128


/*
 *	AX.25 stuff
 */

#define AX25_FLAG	0x7e
#define AX25_UI		0x03
#define AX25_PID_NL3	0xf0
/*
 *	APRS stuff
 */

#define APRS_PID	'!'	/* lat/long without time */


#endif

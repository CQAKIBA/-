/*
 *	atprogrammenu.c
 *
 *	Copyright Jeroen Vreeken (pe1rxq@amsat.org) 2003, 2004, 2005
 *
 *	Published under the terms of the GNU General Public License
 *	version 2.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <time.h>
#include <termios.h>

#define memver 0x02

unsigned char ee_data[79];
char tversion;	// software version as read from connected tracker
char tmemver;	// memory map version as read from connected tracker
char sb_enabled;

enum {
	ATBAUD_4K8,
	ATBAUD_9K6
};

int baud = ATBAUD_9K6;

int read_eeprom(int fd_ser)
{
	char buffer[2];
	int i;

	for (i=0; i<79; i++) {
		buffer[0]='R';
		buffer[1]=i;
		write(fd_ser, buffer, 2);
		if (read(fd_ser, ee_data+i, 1)!=1)
			return -1;
	}
	
	return 0;
}

int write_eeprom(int fd_ser)
{
	unsigned char buffer[3];
	int i;

	for (i=0; i<79; i++) {
		buffer[0]='W';
		buffer[1]=i;
		buffer[2]=ee_data[i];
		write(fd_ser, buffer, 3);
		if (read(fd_ser, buffer, 1)!=1)  {
			return -1;
		}
		if (buffer[0]!=ee_data[i]) {
			return 1;
		}
	}
	
	return 0;
}

void print_content(void)
{
	int i;
	printf("\n");
	printf("****************************************************************************\n");
	printf("Found APRS Tracker software version %d ", tversion);
	printf("in %d baud mode.\n", baud==ATBAUD_4K8 ? 4800 : 9600);
	printf("****************************************************************************\n");
	printf("Eeprom contents:\n");
	printf("----------------------------------------------------------------------------\n");
	printf("Source address: \t");
	for (i=0; i<6; i++) {
		printf("%c", ee_data[i+7]>>1);
	}
	printf("-%c\n", ee_data[13]>>1);
/*	printf("Destination address:\t");
	for (i=0; i<6; i++) {
		printf("%c", ee_data[i]>>1);
	}
	printf("-%c\n", ee_data[6]>>1); 	*/
	printf("Beacon interval:\t%d", ee_data[0x1c]);
	if (tmemver == 0x02) {
		if (ee_data[0x1c] == 0) {
			sb_enabled = 1;
			printf(" (SmartBeaconing enabled)");
		} else {
			sb_enabled = 0;
			printf(" (SmartBeaconing disabled)");
		}
	}
	printf("\nTX Delay count: \t%d\n", ee_data[0x1d]);
	printf("Symbol table:\t\t%c\n", ee_data[0x1e]);
	printf("Symbol id:\t\t%c\n", ee_data[0x1f]);
	ee_data[63]=0;
	printf("Beacontext:\t\t%s\n", ee_data+0x20);
	if (sb_enabled) {
		printf("Slow beacon rate:\t%d (minutes)\t", ee_data[0x4c]);
		printf("Slow speed threshold:\t%d (knots)\n", ee_data[0x4d]);
		printf("Fast beacon rate:\t%d (seconds)\t", ee_data[0x4b]);
		printf("Fast speed threshold:\t%d (knots)\n", ee_data[0x4e]);
	}
}

void leave_programming(int fd_ser)
{
	int i;
	/* Feed the tracker some junk to get into a known state */
	for (i=0; i<80; i++)
		write(fd_ser, "X", 1);
}

int enter_programming(int fd_ser)
{
	unsigned char buffer[5];
	fd_set	fdread;
	struct timeval timeout;
	
	leave_programming(fd_ser);
	write(fd_ser, "!", 1);
	usleep(100000);
	FD_ZERO(&fdread);
	FD_SET(fd_ser, &fdread);
	timeout.tv_sec=2;
	timeout.tv_usec=0;
	select(fd_ser+1, &fdread, NULL, NULL, &timeout);
	if (!FD_ISSET(fd_ser, &fdread)) {
		return 1;
	}
	if (read(fd_ser, buffer, 4)!=4) {
		return 1;
	}
	if (!strncmp(buffer, "AT", 2)) {
		tversion=buffer[2];
		tmemver=buffer[3];
		printf("APRSTracker ver: %d memver: %d in programming mode\n", 
		    tversion, tmemver);
		if ((tmemver!=0x01) && (tmemver!=0x02)) {
			printf("Cannot handle this memver!\n");
			return 1;
		}
		return 0;
	}
	return 1;
}

int init_serial(char *serdev)
{
	int fd_ser;
	struct termios ser_tio;

	baud = !baud;

	if ((fd_ser=open(serdev, O_RDWR))<0)
		return -1;
	if (tcgetattr(fd_ser, &ser_tio)<0)
		return -1;
	cfmakeraw(&ser_tio);
	if (baud==ATBAUD_4K8) {
		printf("Trying 4800 baud.\n");
		ser_tio.c_cflag = B4800 | CS8 | CLOCAL | CREAD;
	} else {
		printf("Trying 9600 baud.\n");
		ser_tio.c_cflag = B9600 | CS8 | CLOCAL | CREAD;
	}
	if (tcsetattr(fd_ser, TCSANOW, &ser_tio)<0)
		return -1;
	return fd_ser;
}

void set_call(char *callsign, int offset, int end)
{
	int i;
	
	for (i=0; i<6; i++) {
		if (*callsign && *callsign!='-') {
			if (*callsign < '0' || *callsign > '9')
				*callsign&=~32;
			ee_data[offset+i]=(*callsign)<<1;
			callsign++;
		} else {
			ee_data[offset+i]=' '<<1;
		}
	}
	if (*callsign=='-')
		callsign++;
	if (*callsign)
		ee_data[offset+6]=*callsign<<1;
	else
		ee_data[offset+6]='0'<<1;
	if (end) {
		ee_data[offset+6]|=1;
	}
}

void set_comment(char *comment)
{
	if (!strlen(comment)) {
		ee_data[32]=0;
	} else {
		comment[31]=0;
		strcpy(ee_data+32, comment);
	}
}

void print_menu(void)
{
	printf("****************************************************************************\n");
	printf("Options:\n");
	printf("----------------------------------------------------------------------------\n");
	printf("0   Reread EEPROM\t\t\t");
	printf("1   Set Source address\n");
	printf("2   Set Txdelay\t\t\t\t");
	printf("3   Set Beacon interval\n");
	printf("4   Set Symbol table\t\t\t");
	printf("5   Set Symbol id\n");
	printf("6   Set Beacontext\t\t\t");
	if (tmemver == 0x02) {
		if (!sb_enabled)
			printf("7   Enable SmartBeaconing");
		else {
			printf("\n8   Set Slow beacon rate (minutes)\t");
			printf("9   Set Slow speed threshold (knots)\n");
			printf("A   Set Fast beacon rate (seconds)\t");
			printf("B   Set Fast speed threshold (knots)");
		}
	}
	printf("\n****************************************************************************\n");
	printf("Type your choice and press Enter: ");
	fflush(0);
}

int mainloop (int argc, char **argv)
{
	int fd_ser;
	char buffer[80];
	char value[800];
	char *serdevice="/dev/ttyS0";
	int i=0;

	if (argc>1)
		serdevice=argv[1];

	printf("\n");
	printf("****************************************************************************\n");
	printf("APRSTracker programmer\n");
	printf("Copyright Jeroen Vreeken (pe1rxq@amsat.org) 2003, 2004, 2005\n");
	printf("memver: %d\n", memver);
	printf("****************************************************************************\n");
	printf("\n");

	printf("Initializing serial port...\n");
	if ((fd_ser=init_serial(serdevice))<0) {
		perror("Unable to initialize serial port");
		return 1;
	}

	printf("Connect APRSTracker to the serial port (/dev/ttyS0 or COM1) and press Enter\n");
	read(0, buffer, 80);
	do { 
		printf("Putting APRSTracker in programming mode...\n");
		if (enter_programming(fd_ser)) {
			printf("No programmable APRSTracker found\n");
			printf("Reopening serial port...\n");
			close(fd_ser);
			if ((fd_ser=init_serial(serdevice))<0) {
				perror("Unable to initialize serial port");
			return 1;
			}	
			if (i==1)
				goto bailout;
			printf("Retrying...\n");
		} else
			break;
		i++;
	} while (1);

	printf("Reading current eeprom contents...\n");
	if (read_eeprom(fd_ser)) {
		perror("Error reading eeprom contents");
		goto bailout;
	}

menu:
	print_content();
	print_menu();

	buffer[read(0, buffer, 79)]=0;;
	while (strlen(buffer) && 
	    (buffer[strlen(buffer)-1]=='\n' || buffer[strlen(buffer)-1]=='\r'))
	    	buffer[strlen(buffer)-1]=0;
	if ((buffer[0]!='0') && (buffer[0]!='7')) {
		printf("New value: ");
		fflush(0);
		value[read(0, value, 79)]=0;
		while (strlen(value) && 
		    (value[strlen(value)-1]=='\n' || value[strlen(value)-1]=='\r'))
		    	value[strlen(value)-1]=0;
	}
	switch(buffer[0]) {
		case '0':
			printf("Rereading current eeprom contents...\n");
			if (read_eeprom(fd_ser)) {
				perror("Error reading eeprom contents\n");
				goto bailout;
			}
			break;
		case '1':
			printf("Setting source address...\n");
			set_call(value, 7, 0);
			break;
		case '2':
			printf("Setting txdelay...\n");
			ee_data[0x1d]=atoi(value);
			break;
		case '3':
			printf("Setting beacon interval...\n");
			ee_data[0x1c]=atoi(value);
			break;
		case '4':
			printf("Setting table...\n");
			ee_data[0x1e]=value[0];
			break;
		case '5':
			printf("Setting id...\n");
			ee_data[0x1f]=value[0];
			break;
		case '6':
			printf("Setting comment...\n");
			set_comment(value);
			break;
		case '7':
			if (tmemver == 0x02) {
				printf("Enabling SmartBeaconing...\n");
				ee_data[0x1c]=0;
				break;
			}
		case '8':
			if (tmemver == 0x02) {
				printf("Setting slow beacon rate...\n");
				ee_data[0x4c]=atoi(value);
				break;
			}
		case '9':
			if (tmemver == 0x02) {
				printf("Setting slow speed threshold...\n");
				ee_data[0x4d]=atoi(value);
				break;
			}
		case 'a':
		case 'A':
			if (tmemver == 0x02) {
				printf("Setting fast beacon rate...\n");
				ee_data[0x4b]=atoi(value);
				break;
			}
		case 'b':
		case 'B':
			if (tmemver == 0x02) {
				printf("Setting fast speed threshold...\n");
				ee_data[0x4e]=atoi(value);
				break;
			}
		default:
			printf("Unknown option\n");
			goto menu;
	}
	printf("Writing eeprom contents...\n");
	if (write_eeprom(fd_ser)) {
		perror("Error writing eeprom");
		goto bailout;
	}
	goto menu;

bailout:
	leave_programming(fd_ser);
	return 1;
}

int main (int argc, char **argv) {
	while (1) {
		mainloop(argc, argv);
		sleep(1);
	}
	return 1;
}

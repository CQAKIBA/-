/*
 *	aprstracker.c	v 0.9
 *
 *	Copyright Jeroen Vreeken (pe1rxq@amsat.org), 2003-2006
 *
 *	Published under the terms of the GNU General Public License
 *	version 2. Read the file COPYING for more details.
 *
 *
 *	History:
 *	0.7	(PE1RXQ) first public release
 *	0.8pre	(PE1RXQ) accept GPS data at 9600 bps, inverted serial comm.
 *	0.8	(PE1ICQ) fix smartbeaconing. fix inverted serial comm. detection
 *	0.9	(PE1ICQ) fix bug in constant interval transmisions and
 *		         response to forced beacon (SW3).
 *		         new feature: LSTAT indication depends on SW1
 *
 */


#include <pic.h>
#include "aprstracker.h"

unsigned int seconds = 0; 
unsigned char latitude[8];
unsigned char longitude[9];
unsigned char course[3] = { '0', '0', '0' };
unsigned char speed[3] = { '0', '0', '0' };
char alt5, alt4, alt3, alt2, alt1, alt0;

bit crc;
bit stuffing;
bit tone1200;
bit sendbit;
bit beacon_now = 0;
bit ser_pol;	// FALSE if serial input is inverted
bit tx_toggle;
unsigned char crcl;
unsigned char crch;
unsigned char stuff_cnt;
unsigned char modem_cnt=0;
unsigned char modem_dly;
unsigned char modem_wave;

// SmartBeaconing(tm) stuff.
int sb_POSIT_rate;		// Computed SmartBeaconing(tm) posit rate (secs)
int sb_last_heading = -1;	// Heading at time of last posit
int sb_current_heading;		// Most recent heading parsed from GPS sentence
int sb_current_speed;		// Most recent speed parsed from GPS sentence (knots)
unsigned char turn_threshold;	// Computed turn threshold
signed int heading_change_since_beacon;



/* Convert three ascii digits to int
 * This is used instead of atoi() because it produces smaller code.
 * If we at some point want to reduce code size any further, then we
 * could consider returning a char instead of int. This would mean
 * that we have to devide the result by 2, and we would determine
 * course and speed changes in steps of 2 degrees.
 */
int tdtoi(char *s) {
	int result = 0;
	char c = 0;
	while (c < 3) {
		result = 10*result + (s[c] - '0');
		c++;
	}
	return(result);
}



char eep_read(char addr)
{
	return EEPROM_READ(addr);
}

#define eep_write(addr, val) EEPROM_WRITE(addr, val)

#define TCNT1200	(60)
#define TCNT2200	(31)

#define TWAIT1200	32
#define TWAIT2200	58


interrupt void modem_isr(void)
{
#asm
	bcf	_STATUS, 5		/* Make sure we are on bank 0 */
	movf	_modem_dly, w
	movwf	_TMR0

	incf	_modem_cnt		/* modem_cnt++ */
	incf	_modem_wave		/* modem_wave++ */
	movlw	0x1f			/* modem_wave &= 0x1f */
	andwf	_modem_wave

	movlw	HIGH get_wave		/* get portb value from jump table */
	movwf	_PCLATH, f
	movf	_modem_wave, w
	movwf	_modem_wave
	call	get_wave
	movwf	_PORTB			/* set new DA value */

	bcf	11,2	/* T0IF=0*/
#endasm
	return;
#asm
	
get_wave:
	addwf	_PCL, f
	retlw	8
	retlw	9
	retlw	10
	retlw	12
	retlw	13
	retlw	14
	retlw	14
	retlw	15
	
	retlw	15
	retlw	15
	retlw	14
	retlw	14
	retlw	13
	retlw	12
	retlw	10
	retlw	9

	retlw	8
	retlw	6
	retlw	5
	retlw	3
	retlw	2
	retlw	1
	retlw	1
	retlw	0

	retlw	0
	retlw	0
	retlw	1
	retlw	1
	retlw	2
	retlw	3
	retlw	5
	retlw	6
#endasm
}

#define wait_bit() do \
{ \
	if (tone1200) \
		do CLRWDT(); while (modem_cnt < TWAIT1200); \
	else \
		do CLRWDT(); while (modem_cnt < TWAIT2200); \
	modem_cnt=0; \
} while (0)

#define send_zero() do \
{ \
	if (!tone1200) \
		modem_dly = 6 - TCNT1200; \
	else \
		modem_dly = 6 - TCNT2200; \
	tone1200=!tone1200; \
	stuff_cnt = 0; \
} while (0)


void ax25_putc(char c)
{
	char i;

	for (i=0; i<8; i++) {
		sendbit = c & 1;
		if (crc) {
			#asm
				bcf	03, 0
				rrf	_crch, f
				rrf	_crcl, f
			#endasm
			if (CARRY != sendbit) {
				crch ^= 0x84;
				crcl ^= 0x08;
			}
		}
		c = c >> 1;
		wait_bit();
		if (sendbit) {
			stuff_cnt++;
			if (stuffing && stuff_cnt == 5) {
				wait_bit();
				send_zero();
			}
		} else
			send_zero();
	}
	
}

void ax25_send(void)
{
	unsigned char i, j;

	for (i=1; i; i++) {
		CLRWDT();
		if (!RXDET && SW1) {
			i=1;
			LSTAT = 1;
		} else
			LSTAT = 0;
		for (j=0; j<32; j++);
	}
	PTT = 1;

	tone1200 = 0;
	PSA = 1;
	T0CS = 0;
	TMR0 = 2 - TCNT1200;

	GIE = 1;
	
	crcl = 0xff;
	crch = 0xff;
	crc = 0;

	/* we count txdelay in flags instead of ms */	
	for (i=eep_read(EE_TXDELAY); i; i--)
		ax25_putc(0);
	ax25_putc(AX25_FLAG);

	crc = 1;
	stuffing = 1;
	stuff_cnt = 0;

	/* destination, source, digis */
	i=0;
	do {
		j=eep_read(i++);
		ax25_putc(j);
	} while (!(j & 1));
	
	/* ax25 control & PID */
	ax25_putc(AX25_UI);
	ax25_putc(AX25_PID_NL3);
	
	/* aprs packet identifier */
	ax25_putc(APRS_PID);

	/* latitude */
	for (i=0; i<8; i++)
		ax25_putc(latitude[i]);

	/* symbol table */
	ax25_putc(eep_read(EE_SYMBOLTABLE));

	/* longitude */
	for (i=0; i<9; i++)
		ax25_putc(longitude[i]);

	/* symbol id */
	ax25_putc(eep_read(EE_SYMBOLID));

	/* course/speed */
	for (i=0; i<3; i++)
		ax25_putc(course[i]);
	ax25_putc('/');
	for (i=0; i<3; i++)
		ax25_putc(speed[i]);

	/* Altitude */
	ax25_putc('/');
	ax25_putc('A');
	ax25_putc('=');
	ax25_putc(alt5+'0');
	ax25_putc(alt4+'0');
	ax25_putc(alt3+'0');
	ax25_putc(alt2+'0');
	ax25_putc(alt1+'0');
	ax25_putc(alt0+'0');
	ax25_putc(' ');

	i=EE_BEACONTEXT;
	while ((j=eep_read(i++)))
		ax25_putc(j);

	crc = 0;
	crcl ^= 0xff;
	crch ^= 0xff;
	ax25_putc(crcl);
	ax25_putc(crch);

	stuffing = 0;
	ax25_putc(AX25_FLAG);
	ax25_putc(AX25_FLAG);

	PTT = 0;
	GIE = 0;
}




/*
	RS232 behaviour depends on SW2:

	The polarity (TTL or RS232) is determined at start-up.

	SW2 open:	4800 baud
	SW2 closed:	9600 baud

	For 'normal' aka 'tinytrack' behaviour leave switch open (=high).
 */

char w;
char getch(void)
{
	char c;
	char i;

	while ((!RXD && ser_pol) || (RXD && !ser_pol)) {
		CLRWDT();
		if (RXDET && SW1)
			LSTAT = 0;
		else
			LSTAT = 1;
	}
	c = 0;
	
	w = 40;
	#asm
	getch_wait1:
	decfsz	_w
	goto getch_wait1
	#endasm
	
	i = 8;
	do {
		CLRWDT();
		if (SW2)
			w = 170;
		else
			w = 81;
		#asm
		getch_wait2:
		decfsz	_w
		goto 	getch_wait2
		#endasm
	
		c /= 2;
		if (ser_pol) {
			if (!RXD)
				c |= 128;
		} else {
			if (RXD)
				c |= 128;
		}
	} while (--i);
	if (SW2)
		w = 170;
	else
		w = 81;
	#asm
	getch_wait3:
	decfsz	_w
	goto	getch_wait3
	#endasm

	if ((ser_pol && RXD) || (!ser_pol && !RXD))
		ser_pol =! ser_pol;

	return c;
}


void putch(char val)
{
	char i;

	TXD = ser_pol;	/* start bit */

	i = 10;
	do {
		w = 81;
		if (SW2)
			w += 89;
//		else
//			w = 81;
		#asm
			putch_wait:
			decfsz	_w
			goto	putch_wait
		#endasm
		CLRWDT();
		if (val & 1)
			TXD = !ser_pol;
		else
			TXD = ser_pol;
		val = (val >> 1) | 0x80;
	} while (--i);
}


void programmode(void)
{
	char c;

	putch('A');
	putch('T');
	putch(APRSTRACKER_VERSION);
	putch(APRSTRACKER_EEVERSION);

wait_programmode:
	c=getch();
	if (c=='W') {
		c=getch();
		eep_write(c, getch());
		putch(eep_read(c));
		goto wait_programmode;
	}
	if (c=='R') {
		putch(eep_read(getch()));
		goto wait_programmode;
	}
	/* a char other than W or R quits programmode */
}

void getcomma(void)
{
	while (getch() != ',');
}

void main(void)
{
	unsigned char c, d, t;

	CLRWDT();
	INTCON = 0;	/* Disable all interrupts (also GIE) */
	T0IE = 1;

#if defined(_16F627) || defined(_16F628)
	/* Make 16F6xx ports behave like 16F84
	 * (Turn off comparators)
	 */
	CMCON=0x07;
#endif
	RBPU=0;
	/* port directions */
	INIT_PORTA;
	INIT_PORTB;
	
	if (SW1)
		LSTAT = 1; 	/* status led on, (used for RXDET indicatior) */
	else
		LSTAT = 0; 	/* status led off (used for GPS lock indicator) */
	
	LGPS = 1; 		/* gps led on */
	PTT = 0;		/* ptt off */

	/* wait for serial data */
wait_ser:
	CLRWDT();
	c = getch();
	if (c != '$') {
		if (c == '!') {
			programmode();
		}
		goto wait_ser;
	}
	if (getch() != 'G')
		goto wait_ser;
	if (getch() != 'P')
		goto wait_ser;
	LGPS = !LGPS;	/* toggle gps led */
	c = getch();
	if (c != 'G') {
		if (c == 'V')
			goto gpvtg;
		else
			goto wait_ser;
	}
	if (getch() != 'G')
		goto wait_ser;
	if (getch() != 'A')
		goto wait_ser;
	
	/* We have a GPGGA sentence */

	seconds++;
	if (eep_read(EE_BEACONTIME) != 0) {
		if (seconds >= (eep_read(EE_BEACONTIME) * 60))
			beacon_now = 1;
		else
			beacon_now = 0;	
	}
	
	if ( SEND && !beacon_now )
		goto wait_ser;

	/* Time to send our packet or forced to,
	   first collect the rest of the NMEA sentence */
	// LSTAT = 1;

	getch();			/* first comma */
	getcomma();			/* timestamp + second comma */
	latitude[0] = getch();
	latitude[1] = getch();
	latitude[2] = getch();
	latitude[3] = getch();
	latitude[4] = getch();
	latitude[5] = getch();
	latitude[6] = getch();
	getcomma();			/* comma */
	latitude[7] = getch();		/* N/S */
	getcomma();			/* comma */
	longitude[0] = getch();
	longitude[1] = getch();
	longitude[2] = getch();
	longitude[3] = getch();
	longitude[4] = getch();
	longitude[5] = getch();
	longitude[6] = getch();
	longitude[7] = getch();
	getcomma();			/* comma */
	longitude[8] = getch();		/* E/W */
	getch();			/* comma */
	if (getch() == '0' || latitude[0]==',') {
		/* Oops, no valid data....
		 * We try again in one minute
		 */
		 seconds -= 60;
		 if (!SW1)
		 	LSTAT = 0;	/* status led off */
		 goto wait_ser;
	}
	/*
	 * If we get to this point then we have valid GPS data
	 * i.e. GPS is locked. If SW1 jumper is placed, then turn 
	 * on status LED to indicate this. This is usefull for 
	 * GPS modules that don't have a lock indicator.
	 */
	if (!SW1)
		LSTAT = 1;	/* status led on */

	getch();			/* comma */
	getcomma();			/* skip nr. of sats */
	getcomma();			/* skip accuracy */
	alt0=0;
	alt1=0;
	alt2=0;
	alt3=0;
	alt4=0;
	alt5=0;
	d=getch();
	c=0;
	if (d!='-') do {
		alt5=alt4;
		alt4=alt3;
		alt3=alt2;
		alt2=alt1;
		alt1=alt0;
		t=(d-'0')*33;
		while (t > 99) {
			t-=100;
			alt1++;
			if (alt1 > 9) {
				alt1-=10;
				alt2++;
				if (alt2 > 9) {
					alt2-=10;
					alt3++;
					if (alt3 > 9) {
						alt3-=10;
						alt4++;
						if (alt4 > 9)
							alt4-=10;
							alt5++;
					}
				}
			}
		}
		alt0=(t/10)+c;
		if (alt0 > 9) {
			alt0-=10;
			alt1++;
			if (alt1 > 9) {
				alt1-=10;
				alt2++;
				if (alt2 > 9) {
					alt2-=10;
					alt3++;
					if (alt3 > 9) {
						alt3-=10;
						alt4++;
						if (alt4 > 9) {
							alt4-=10;
							alt5++;
						}
					}
				}
			}
		}
		c=t;
		while (c > 9)
			c-=10;
		d=getch();
	} while (d!=',' && d!='.');


	
	/* Send the packet */
	ax25_send();
	beacon_now = 0;
	seconds = 2;	/* time offset for sending packet */

	goto wait_ser;

gpvtg:
	if (getch() != 'T')
		goto wait_ser;
	if (getch() != 'G')
		goto wait_ser;
	getch();			/* first comma */
					/* ground course */
	course[1]='0';
	course[2]='0';
	c='0';
	do {
		course[0]=course[1];
		course[1]=course[2];
		course[2]=c;
		c=getch();
	} while (c!='.' && c!=',');

	while (getch() != 'M');		/* end of magnetic course */
	getch();			/* comma */
					/* Speed in knots.. stupid spec.. */
	speed[1] = '0';
	speed[2] = '0';
	c = '0';
	do {
		speed[0]=speed[1];
		speed[1]=speed[2];
		speed[2]=c;
		c=getch();
	} while (c!='.' && c!=',');

	
	/* Code to compute SmartBeaconing(tm) rates. (borrowed from Xastir)
	 *
	 * SmartBeaconing(tm) was invented by Steve Bragg (KA9MVA) and
	 * Tony Arnerich (KD7TA).
	 * Its main goal is to change the beacon rate based on speed
	 * and cornering.  It does speed-variant corner pegging and
	 * speed-variant posit rate.
	 *
	 * Several special SmartBeaconing(tm) parameters come into play here:
	 *
	 * sb_turn_min          Minimum degrees at which corner pegging will
	 *                      occur.  The next parameter affects this for
	 *                      lower speeds.
	 *
	 * sb_turn_slope        Fudget factor for making turns less sensitive at
	 *                      lower speeds.  No real units on this one.
	 *                      It ends up being non-linear over the speed
	 *                      range the way the original SmartBeaconing(tm)
	 *                      algorithm works.
	 *
	 * sb_turn_time         Dead-time before/after a corner peg beacon.
	 *                      Units are in seconds.
	 *
	 * sb_posit_fast        Fast posit rate, used if >= sb_high_speed_limit.
	 *                      Units are in seconds.
	 *
	 * sb_posit_slow        Slow posit rate, used if <= sb_low_speed_limit.
	 *                      Units are in minutes.
	 *
	 * sb_low_speed_limit   Low speed limit, units are in knots.
	 *
	 * sb_high_speed_limit  High speed limit, units are in knots.
	 */

	#define sb_turn_min		eep_read(SB_TURN_MIN)
	#define sb_turn_slope		eep_read(SB_TURN_SLOPE)
	#define sb_turn_time		eep_read(SB_TURN_TIME)
	#define sb_posit_fast		eep_read(SB_POSIT_FAST)
	#define sb_posit_slow 		eep_read(SB_POSIT_SLOW)
	#define sb_low_speed_limit	eep_read(SB_LOW_SPEED_LIMIT)
	#define sb_high_speed_limit	eep_read(SB_HIGH_SPEED_LIMIT)

	// only do SmartBeaconing if EE_BEACONTIME == 0
	if ( eep_read(EE_BEACONTIME) == 0 ) {

		sb_current_speed = tdtoi(speed);	//convert the 3 ascii chars to a single integer that we can use for calculations
		sb_current_heading = tdtoi(course);	//convert the 3 ascii chars to a single integer that we can use for calculations

		if (sb_current_speed <= sb_low_speed_limit) {
			// Set to slow posit rate
			sb_POSIT_rate = (sb_posit_slow) * 60; // Convert to seconds
			/* Reset heading_change_since_beacon to avoid cyclic 
			   triggering of beacon_now when we suddenly drop below
			   the low speed limit. */
			heading_change_since_beacon = 0;
		}
		else { // We're moving faster than the low speed limit
		       // Start with turn_min degrees as the threshold
			turn_threshold = sb_turn_min;
			
			// Adjust rate according to speed
			if (sb_current_speed > sb_high_speed_limit) {
				// We're above the high limit
				sb_POSIT_rate = sb_posit_fast;
			}
			else {  // We're between the high/low limits.  Set a between rate
				sb_POSIT_rate = (sb_posit_fast * sb_high_speed_limit) / sb_current_speed;
				// Adjust turn threshold according to speed
				turn_threshold += (unsigned char)( (sb_turn_slope * 10) / sb_current_speed);
			}
			
			// Force a maximum turn threshold of 80 degrees 
			if (turn_threshold > 80)
			    turn_threshold = 80;
			
			// Check to see if we've written anything into
			// sb_last_heading variable yet.  If not, write the current
			// course into it.
			if (sb_last_heading == -1)
			    sb_last_heading = sb_current_heading;
			
			// Corner-pegging.  Note that we don't corner-peg if we're
			// below the low-speed threshold.
			heading_change_since_beacon = sb_current_heading - sb_last_heading;
			if (heading_change_since_beacon < 0)
				heading_change_since_beacon = sb_last_heading - sb_current_heading;
			if (heading_change_since_beacon > 180)
			    heading_change_since_beacon = 360 - heading_change_since_beacon;
		}

		if ( ( (heading_change_since_beacon > turn_threshold)
		          && (seconds > sb_turn_time) )
		       || (seconds > sb_POSIT_rate) ) {
			beacon_now = 1;                       // Force a posit right away
			sb_last_heading = sb_current_heading; // and save save current course.
		}	                                      // We'll use in the the calculation above
			                                      // to determine next posit.
	}

	goto wait_ser;
}
